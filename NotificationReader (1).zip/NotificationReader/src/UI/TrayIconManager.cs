using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using NotificationReader.Services;
using NotificationReader.Windows;
using Application = System.Windows.Application;
using MessageBox = System.Windows.MessageBox;

namespace NotificationReader.UI;

/// <summary>
/// Builds and manages the system tray icon and its context menu. This is the
/// only user-facing surface of the app when idle.
/// </summary>
public class TrayIconManager : IDisposable
{
    private readonly SettingsService _settingsService;
    private readonly SpeechService _speechService;
    private readonly NotificationService _notificationService;

    private NotifyIcon? _notifyIcon;
    private ContextMenuStrip? _menu;
    private ToolStripMenuItem? _toggleItem;
    private ToolStripMenuItem? _voiceMenu;
    private ToolStripMenuItem? _rateMenu;

    private ToolStripMenuItem? _rateSlow;
    private ToolStripMenuItem? _rateNormal;
    private ToolStripMenuItem? _rateFast;

    private SettingsWindow? _settingsWindow;
    private bool _disposed;

    public TrayIconManager(
        SettingsService settingsService,
        SpeechService speechService,
        NotificationService notificationService)
    {
        _settingsService = settingsService;
        _speechService = speechService;
        _notificationService = notificationService;
    }

    public Task InitializeAsync()
    {
        _menu = new ContextMenuStrip();

        // Toggle: Reading Notifications
        _toggleItem = new ToolStripMenuItem("Reading Notifications")
        {
            CheckOnClick = true,
            Checked = _settingsService.Settings.IsEnabled
        };
        _toggleItem.Click += OnToggleClicked;
        _menu.Items.Add(_toggleItem);

        _menu.Items.Add(new ToolStripSeparator());

        // Voice submenu
        _voiceMenu = new ToolStripMenuItem("Voice");
        BuildVoiceMenu();
        _menu.Items.Add(_voiceMenu);

        // Speech rate submenu
        _rateMenu = new ToolStripMenuItem("Speech Rate");
        _rateSlow = new ToolStripMenuItem("Slow") { CheckOnClick = false };
        _rateNormal = new ToolStripMenuItem("Normal") { CheckOnClick = false };
        _rateFast = new ToolStripMenuItem("Fast") { CheckOnClick = false };
        _rateSlow.Click += (_, _) => SetRate(0.5);
        _rateNormal.Click += (_, _) => SetRate(1.0);
        _rateFast.Click += (_, _) => SetRate(1.5);
        _rateMenu.DropDownItems.Add(_rateSlow);
        _rateMenu.DropDownItems.Add(_rateNormal);
        _rateMenu.DropDownItems.Add(_rateFast);
        UpdateRateMenu();
        _menu.Items.Add(_rateMenu);

        _menu.Items.Add(new ToolStripSeparator());

        // Filters & Settings
        var settingsItem = new ToolStripMenuItem("Filters && Settings...");
        settingsItem.Click += (_, _) => OpenSettingsWindow();
        _menu.Items.Add(settingsItem);

        _menu.Items.Add(new ToolStripSeparator());

        // Exit
        var exitItem = new ToolStripMenuItem("Exit");
        exitItem.Click += (_, _) => ExitApp();
        _menu.Items.Add(exitItem);

        _notifyIcon = new NotifyIcon
        {
            Icon = LoadAppIcon(),
            Visible = true,
            ContextMenuStrip = _menu,
            Text = BuildTooltip()
        };
        _notifyIcon.DoubleClick += (_, _) => OpenSettingsWindow();

        // Startup balloon.
        try
        {
            _notifyIcon.BalloonTipTitle = "Notification Reader";
            _notifyIcon.BalloonTipText = "Notification Reader started";
            _notifyIcon.ShowBalloonTip(3000);
        }
        catch (Exception ex)
        {
            Logger.Log("Failed to show startup balloon.", ex);
        }

        return Task.CompletedTask;
    }

    private void BuildVoiceMenu()
    {
        if (_voiceMenu == null)
        {
            return;
        }

        _voiceMenu.DropDownItems.Clear();

        var voices = _speechService.NaturalVoices;
        if (voices.Count == 0)
        {
            _voiceMenu.DropDownItems.Add(new ToolStripMenuItem("(No voices found)") { Enabled = false });
            return;
        }

        foreach (var voice in voices)
        {
            var item = new ToolStripMenuItem(voice.DisplayName)
            {
                Tag = voice.Id,
                Checked = voice.Id == (_settingsService.Settings.SelectedVoiceId?.Length > 0
                    ? _settingsService.Settings.SelectedVoiceId
                    : _speechService.CurrentVoiceId)
            };
            item.Click += OnVoiceClicked;
            _voiceMenu.DropDownItems.Add(item);
        }
    }

    private async void OnVoiceClicked(object? sender, EventArgs e)
    {
        if (sender is not ToolStripMenuItem item || item.Tag is not string voiceId)
        {
            return;
        }

        _speechService.SetVoice(voiceId);
        _settingsService.Settings.SelectedVoiceId = voiceId;
        UpdateVoiceMenu();
        await _settingsService.SaveAsync();
    }

    /// <summary>Refreshes the check marks in the voice submenu.</summary>
    public void UpdateVoiceMenu()
    {
        if (_voiceMenu == null)
        {
            return;
        }

        string? selected = _settingsService.Settings.SelectedVoiceId?.Length > 0
            ? _settingsService.Settings.SelectedVoiceId
            : _speechService.CurrentVoiceId;

        foreach (ToolStripItem obj in _voiceMenu.DropDownItems)
        {
            if (obj is ToolStripMenuItem mi && mi.Tag is string id)
            {
                mi.Checked = id == selected;
            }
        }
    }

    private async void SetRate(double rate)
    {
        _speechService.SetRate(rate);
        _settingsService.Settings.SpeechRate = rate;
        UpdateRateMenu();
        await _settingsService.SaveAsync();
    }

    private void UpdateRateMenu()
    {
        double rate = _settingsService.Settings.SpeechRate;
        if (_rateSlow != null) _rateSlow.Checked = Math.Abs(rate - 0.5) < 0.01;
        if (_rateNormal != null) _rateNormal.Checked = Math.Abs(rate - 1.0) < 0.01;
        if (_rateFast != null) _rateFast.Checked = Math.Abs(rate - 1.5) < 0.01;

        // If the stored rate is a custom value, none are checked but Normal is the closest default.
        if (_rateSlow is { Checked: false } && _rateNormal is { Checked: false } && _rateFast is { Checked: false })
        {
            if (_rateNormal != null && rate > 0)
            {
                // Leave unchecked to reflect the custom value truthfully.
            }
        }
    }

    private async void OnToggleClicked(object? sender, EventArgs e)
    {
        bool enabled = _toggleItem?.Checked ?? true;
        _notificationService.IsEnabled = enabled;
        _speechService.IsEnabled = enabled;
        _settingsService.Settings.IsEnabled = enabled;

        if (_notifyIcon != null)
        {
            _notifyIcon.Text = BuildTooltip();
        }

        await _settingsService.SaveAsync();
    }

    private string BuildTooltip()
    {
        string state = _settingsService.Settings.IsEnabled ? "On" : "Off";
        return $"Notification Reader — Reading: {state}";
    }

    private void OpenSettingsWindow()
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            if (_settingsWindow != null)
            {
                try
                {
                    _settingsWindow.Activate();
                    return;
                }
                catch
                {
                    _settingsWindow = null;
                }
            }

            _settingsWindow = new SettingsWindow(_settingsService, ((App)Application.Current).FilterService);
            _settingsWindow.Closed += (_, _) => _settingsWindow = null;
            _settingsWindow.Show();
            _settingsWindow.Activate();
        });
    }

    private void ExitApp()
    {
        Application.Current.Dispatcher.Invoke(() =>
        {
            if (_notifyIcon != null)
            {
                _notifyIcon.Visible = false;
            }
            Application.Current.Shutdown();
        });
    }

    private static Icon LoadAppIcon()
    {
        try
        {
            // Try to load the packed resource icon.
            var uri = new Uri("pack://application:,,,/Assets/app.ico", UriKind.Absolute);
            var streamInfo = Application.GetResourceStream(uri);
            if (streamInfo != null)
            {
                using var s = streamInfo.Stream;
                return new Icon(s);
            }
        }
        catch (Exception ex)
        {
            Logger.Log("Failed to load embedded app icon; using system default.", ex);
        }

        // Fallback: load from disk next to the exe, else system default.
        try
        {
            string path = Path.Combine(AppContext.BaseDirectory, "Assets", "app.ico");
            if (File.Exists(path))
            {
                return new Icon(path);
            }
        }
        catch (Exception ex)
        {
            Logger.Log("Failed to load app icon from disk.", ex);
        }

        return SystemIcons.Application;
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }
        _disposed = true;

        try
        {
            if (_notifyIcon != null)
            {
                _notifyIcon.Visible = false;
                _notifyIcon.Dispose();
            }
            _menu?.Dispose();
        }
        catch (Exception ex)
        {
            Logger.Log("Error disposing tray icon.", ex);
        }

        GC.SuppressFinalize(this);
    }
}
